export enum GENDER {
  MALE = "MALE",
  FEMALE = "FEMALE",
}

export enum STATUS {
  ACTIVE = "ACTIVE",
  INACTIVE = "INACTIVE",
}